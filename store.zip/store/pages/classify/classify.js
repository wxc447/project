
Page({

  /**
   * 页面的初始数据
   */
  data: {
    category: [{
        name: "超值特惠",
        id: "cz",
        index:1
      },
      {
        name: "新品上市",
        id: "xp",
        index: 2
      },
      {
        name: "店长推荐",
        id: "tj",
        index: 3
      },
      {
        name: "国产精品",
        id: "gc",
        index: 4
      },
      {
        name: "漂洋过海",
        id: "gh",
        index: 5
      }

    ],
  //   mainTitle: [{
  //       id: "01",  
  //       text1: "超值特惠",
  //     },
  //     {
  //       id: "02",
  //       text1: "新品上市",
  //     },
  //     {
  //       id: "03",
  //       text1: "店长推荐",
  //     },
  //     {
  //       id: "04",
  //       text1: "国产精品",
  //     },
  //     {
  //       id: "05",
  //       text1: "漂洋过海",
  //     },
    
  // ],
  isScroll: true,
  toView: 'tj',
  detail: [],
  currIndex: 0,
  newIndex:""
},

/**
 * 生命周期函数--监听页面加载 只执行一次
 */
onLoad: function (options) {
  this.setData({
    newIndex: this.data.category[0].id
  });

  var that = this;
  wx.request({
    url: 'https://ifonly447.gitee.io/text/fruit.json',
    success: (res) => {
      // console.log(res);
      this.setData({
        detail: res.data
      })
      console.log(this.data.detail)
    }
  })


},

/**
 * 生命周期函数--监听页面初次渲染完成 只执行一次
 */
onReady: function () {
  


},

/**
 * 生命周期函数--监听页面显示  执行N次
 */
onShow: function () {

},

/**
 * 生命周期函数--监听页面隐藏 只执行一次
 */
onHide: function () {

},

/**
 * 生命周期函数--监听页面卸载  只执行一次
 */
onUnload: function () {

},

/**
 * 页面相关事件处理函数--监听用户下拉动作
 */
onPullDownRefresh: function () {

},

/**
 * 页面上拉触底事件的处理函数
 */
onReachBottom: function () {

},

/**
 * 用户点击右上角分享
 */
onShareAppMessage: function () {

},
  // scroll: function (e) {
  //   // console.log("222")
  //   var scrollTop = e.detail.scrollTop,
  //     h = 0,
  //    newIndex;
  //   var that = this;
   
  //   that.data.category.forEach(function (clssfiy, i) {
  //     that.length(clssfiy['id'])
  //     var _h = 9 + that.data.currIndex * 125;
  //     console.log(_h + "这是高度")
  //     if (scrollTop >= h) {
  //       newIndex = clssfiy['id']; 
  //     }
  //     h += _h;
  //     console.log(clssfiy['id']+"这个是id");
  //   })
  //   that.setData({
  //     newIndex: newIndex,
  //   })
  // },
//  length: function (e) {
//     var that = this;

//     var rightData = that.data.detail;
//     // console.log(rightData)
//     for (var i = 0; i < rightData.length; i++) {
//       if (rightData['id'] == e) {
//         return rightData[i]['detail'].length;
//       }
     
//     that.setData({
//       currIndex: rightData[i]['detail'].length
//     })
//     console.log(this.data.currIndex)
//     }
//   },
switchTab(e) {
  let target = e.currentTarget.dataset.id;

  this.setData({
    toView:target,
    currIndex: e.currentTarget.dataset.index
  })
  console.log(this.data.toView)
  console.log(this.data.currIndex)
},
details: function (e) {

  var obj = e.currentTarget.dataset;
  wx.setStorageSync("details", obj);
  console.log(obj);
}

})