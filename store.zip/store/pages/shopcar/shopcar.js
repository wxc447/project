// pages/car/car.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    hasList: false,           // 列表是否有数据,判断是否显示
    totalPrice: 0,           // 总价，初始值为0
    selectAllStatus: true,   // 全选状态，默认全选 
    carts: []                // 购物车列表
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    //1.获取详情也传递过来的数据
    var carts = wx.getStorageSync("carts");
    console.log(carts)
    if (carts) {
      this.setData({
        hasList: true,
        carts: carts
      })
    }
    // 调用总价的封装函数
    this.getTotalPrice();
  },
  // 绑定减数量事件
  minusCount(e) {
    // 点击的时候得到data-index 的值
    var index = e.currentTarget.dataset.index;
    // 获取当前的购物车列表
    var carts = this.data.carts;
    // 获取对象中的newestnum1 的值
    var num = carts[index].num;
    // 做判断  num的不能为负值
    if (num <= 1) {
      return false
    }
    // 递减
    num--;
    // 做完运算之后，重新赋值回去
    carts[index].num = num;
    // 更新数据carts
    this.setData({
      carts: carts
    });
    // 调用总价的封装函数
    this.getTotalPrice();
  },
  // 绑定加数量事件
  addCount(e) {
    // 点击的时候得到data-index 的值
    var index = e.currentTarget.dataset.index;
    // 获取当前的购物车列表
    var carts = this.data.carts;
    // 获取对象中的newestnum1 的值
    var num = carts[index].num;
    // 递增
    num++;
    // 做完运算之后，重新赋值回去
    carts[index].num = num;
    // 更新数据carts
    this.setData({
      carts: carts
    });
    // 调用总价的封装函数
    this.getTotalPrice();
  },
  // 计算总价
  getTotalPrice() {
    var carts = this.data.carts;                  // 获取购物车列表
    var total = 0;
    var num = 0;
    for (let i = 0; i < carts.length; i++) {         // 循环列表得到每个数据
      if (carts[i].selected) {                   // 判断选中才会计算价格
        total += carts[i].num * carts[i].price;    // 所有价格加起来
        num += carts[i].num;
         console.log(total)
      }
    }
    this.setData({                                // 最后赋值到data中渲染到页面
      carts: carts,
      totalCount: num,
      totalPrice: total.toFixed(2)

    });
   
  },


  // getTotalPrice() {
  //   // 总价=当前商品的数量*商品的单价 
  //   // 第一步获取carts购物车列表
  //   var carts = this.data.carts;
  //   // 第二步循环获取每一个商品的数量及单价,求总赋值给
  //   var total = 0;
  //   for (var i in carts) {
  //     // 做判断
  //     if (carts[i].selected) {
  //       // 计算总价
  //       total += carts[i].num * carts[i].price;

  //       total = parseFloat(total).toFixed(2);
  //     }
  //     console.log(total)
  //   };
  //   // 更新数据
  //   this.setData({
  //     totalPrice: total,
  //     carts: carts
  //   });
  // },
  // 当前商品的选中事件
  selectList(e) {
    // 点击的时候得到data-index 的值
    var index = e.currentTarget.dataset.index;
    // 获取当前的购物车列表
    var carts = this.data.carts;
    // 获取对象中的newestSelected1 的值
    var selected = carts[index].selected;
    // 把对象中的newestSelected1 的值取反
    carts[index].selected = !selected;
    // 更新数据carts
    this.setData({
      carts: carts
    });
    // 调用总价的封装函数
    this.getTotalPrice();
  },
  // 绑定删除购物车当前商品事件
  deleteList(e) {
    // 点击的时候得到data-index 的值
    var index = e.currentTarget.dataset.index;
    // 获取当前的购物车列表
    var carts = this.data.carts;
    // 数组中的数据怎么删除 arr.splice(index,1)
    carts.splice(index, 1);
    // 更新数据carts
    this.getTotalPrice();
    // this.setData({
    //   carts: carts
    // });
    console.log(carts)
    this.setData({                                // 最后赋值到data中渲染到页面
      carts: carts,
    });
    
   this.getTotalPrice();
    
    // 判断carts中没有数据了，把hasList的值改成false
    if (!carts.length) {
      this.setData({
        hasList: false
      });
    };
  },
  details: function (e) {

    var obj = e.currentTarget.dataset;
    wx.setStorageSync("details", obj);
    console.log(obj);
  },
  // 绑定删除购物车当前商品事件
  deleteList(e) {
    // 点击的时候得到data-index 的值
    var index = e.currentTarget.dataset.index;
    // 获取当前的购物车列表
    var carts = this.data.carts;
    // 数组中的数据怎么删除 arr.splice(index,1)
    carts.splice(index, 1);
    console.log(index);
    wx.clearStorage()
    // 更新数据carts
    this.setData({
      carts: carts
    });
    console.log(carts);
    wx.setStorage({
      key: 'carts',
      data: carts,
    })
    // 判断carts中没有数据了，把hasList的值改成false
    if (!carts.length) {
      this.setData({
        hasList: false
      });
    };
    this.getTotalPrice();

    //当在tabs栏中跳转到carts页面，也需要把删除的数据清空
    //获取缓存当中carts的数据，点击删除的时候也需要把carts的数据同步删除
    // var carts1 = wx.getStorageSync("carts");
    // 数组中的数据怎么删除 arr.splice(index,1)
    // carts1.splice(index, 1);
    // 更新缓存中的数据carts
    // wx.setStorageSync("carts", carts1);
  },
  //  绑定全部选中事件
  selectAll(e) {
    // 点击时得到 全选选中的值
    let selectAllStatus = this.data.selectAllStatus;
    // 选中状态取反 
    selectAllStatus = !selectAllStatus
    // 关联的商品newestselected1的值
    // 第一步得到carts数组数据
    let carts = this.data.carts;
    // 第二步遍历数组得到每一项（对象）的newestselected1的值
    for (var i in carts) {
      carts[i].selected = selectAllStatus;
    };
    // 更新数据
    this.setData({
      selectAllStatus: selectAllStatus,
      carts: carts
    });
    // 调用总价的封装函数
    this.getTotalPrice();
  },
  navigator:function(){
    wx.switchTab({
      url: '../index/index'
    })
  }
})