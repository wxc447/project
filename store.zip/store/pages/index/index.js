Page({

  /**
   * 页面的初始数据
   */
  data: {
  
    imgUrls: [
      'http://a4.qpic.cn/psb?/V13tLaYq0kIWee/9dUdRImOfCBeklBRGc66IaWb913aLGkSYLR6.Pcjpfw!/m/dL8AAAAAAAAAnull&bo=9AFFAQAAAAARB4E!&rf=photolist&t=5',
      'http://a3.qpic.cn/psb?/V13tLaYq0kIWee/IIBG9zTlj8OOGxJKVyU4fvfqV0X7HLRFCHsRpAdMsaM!/m/dLYAAAAAAAAAnull&bo=9AFFAQAAAAARB4E!&rf=photolist&t=5',
      'http://a3.qpic.cn/psb?/V13tLaYq0kIWee/twLkoGjlp1HQYNrI2CcET6OEpiDv2khGAiUIz9LJQ0c!/m/dLYAAAAAAAAAnull&bo=9AFFAQAAAAARB4E!&rf=photolist&t=5'
    ],
  
    // item:[],
    interval: 2000,
    duration: 1000,
    detail: []

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.request({
      url: 'https://wxc447.github.io/oldWang/fruit.json',
      success: (res) => {
        // console.log(res);
        this.setData({
          detail: res.data[4].detail
        })
        // console.log(this.data.detail)
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  },

  details: function (e) {

    var obj = e.currentTarget.dataset;
    obj.detail = "这里是商品详情";
    obj.parameter = "125g/个";
    obj.service = "不支持退货";
    wx.setStorageSync("details", obj);
    console.log(obj);
  }
})