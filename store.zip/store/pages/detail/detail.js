// pages/details/details.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    goods: {
    },
    currIndex: 0,  // 下面tab栏切换的下标
    num: 1,   // 购物车数量加减
    show: false,   // 购物车图标
    totalNum: 0,   // 购物车上面图标的数量
    hasCarts: false,  // 购物车图标
    scaleCart: false,  // 购物车图标
    carts: [] ,   // 传递给购物车
    index:0,
    newNum:0
 
    
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // 去缓存当中details的对象
    var details = wx.getStorageSync("details");

    // 更新data中的数据
    this.setData({
      goods: details
    })


    // 第一步  carts的镜像数据（存挡）
    var carts = wx.getStorageSync("carts") || [];
    // 第二步  添加到缓存当中 相当于做了一个镜像
    wx.setStorageSync("carts", carts)

  },
  // 下面tab切换栏
  bindTap: function (e) {
    console.log(e)
    var index = e.currentTarget.dataset.index;
    console.log(index)
    this.setData({
      currIndex: index
    })
  },
  // 数量 - 号事件
  downCount() {
    var addNum = this.data.num;
    // console.log(addNum)
    addNum--;
    if (addNum <= 1) {
      addNum = 1;
    }
    // console.log(addNum)
    this.setData({
      num: addNum
    })
  },
  // 数量 + 号事件
  addCount() {
    var addNum = this.data.num;
    // console.log(addNum)
    addNum++;
    // console.log(addNum)
    this.setData({
      num: addNum
    })
    
  },
  // 加入购物车事件
  addToCart() {
    // 1.购物车消息图标
    
   
    var cartNum=this.newNum;
    var that = this;
    cartNum = this.data.num;

    console.log(this.data.index)
    if (this.data.index==0){
      console.log(cartNum);
      
      console.log(this.data.index)
      this.setData({
        index: this.data.index+1,
        newNum:cartNum
      })
      console.log(this.data.index)
    }
    else{
      
      cartNum=this.data.newNum + this.data.num
      this.setData({
        newNum:cartNum

      })
      console.log(this.data.carts)
      wx.setStorageSync("carts", this.data.carts);

      console.log(cartNum)
     
      
    }
   
   
    // let totalNum = this.data.totalNum;
    this.setData({
      show: true
    });
    // 2.延时定时器
    setTimeout(function () {
      that.setData({
        show: false,
        scaleCart: true
      })
      setTimeout(function () {
        that.setData({
          scaleCart: false,
          hasCarts: true,
          totalNum: cartNum
        })
      }, 200)
    }, 300)
   

    // 3.1  去缓存中拿取 carts的镜像数据
    var carts = wx.getStorageSync("carts");
    // 3.2  拿每次进来的list数据  newestListCart
    var details = wx.getStorageSync("details");
    // 3.3  准备给cart页面传值 往newestListCart:{}对象数据,添加catr页面中需要的数据 添加是数量num，所选中的状态selected
    details.num = this.data.newNum;
    details.selected = true;
    // 3.4  再判断缓存中拿取 carts的镜像数据中有没有数据
    if (carts.length >= 0) {
      carts.push(details);
    }
    // 3.5  更新data数据中的carts
    this.setData({
      carts: carts
    });

    wx.setStorageSync("carts", this.data.carts);
    console.log(this.data.carts)
  },
  // addToCart:function(){
  //   wx.setStorageSync("carts", this.data.carts);
  // },
  //  跳转到购物车  且把当前页面的数据保存到缓存  carts:[]
  addCarts: function () {
    // 存档缓存 
    wx.setStorageSync("carts", this.data.carts);
  }

})